#include <iostream>  
#include <opencv2\core\core.hpp>  
#include <opencv2\highgui\highgui.hpp>  
#include <opencv2\imgproc\imgproc.hpp>  
#include<cmath>
#include<opencv2/opencv.hpp>
#include<iostream>
#include<math.h>
#include <vector>
#include "cv.h"



using namespace cv;
using namespace std;

//��ϰ1������
Mat gammaTrans(Mat & srcImage, float r) {
	//�������Lut
	unsigned char Lut[256];
	for (int i = 0; i < 256; i++)
	{
		//��������֮��,���Ϊ��,��תΪ0,�������255,��Ϊ255��
	/*	float f = (i + 0.5f) / 255;
		f = (float)(pow(f, r));
		Lut[i] = saturate_cast<uchar>(f*255.0f - 0.5f);*/

	float f = i / 255.0f;
	f = (float)(pow(f, r));
	Lut[i] = (float) (f * 255.0f);

	}
	Mat resultSrc = srcImage.clone();

	if (srcImage.channels() == 1)
	{
		MatIterator_<uchar> iterator = resultSrc.begin<uchar>();
		MatIterator_<uchar> iteratorEnd = resultSrc.end<uchar>();
		for (; iterator != iteratorEnd; iterator++)
		{
			*iterator = Lut[(*iterator)];
		}
	}
	else
	{
		MatIterator_<Vec3b> iterator = resultSrc.begin<Vec3b>();
		MatIterator_<Vec3b> iteratorEnd = resultSrc.end<Vec3b>();
		for (; iterator != iteratorEnd; iterator++)
		{
			(*iterator)[0] = Lut[(*iterator)[0]];//b
			(*iterator)[1] = Lut[(*iterator)[1]];//g
			(*iterator)[2] = Lut[(*iterator)[2]];//r
		}
	}
	return resultSrc;

	for (int i = 0; i < 256; i++)
	{
		cout << Lut[i] << endl;
	}
}

//��ϰ3
int main() 
{
	Mat src = imread("C:/Users/hurricane/Desktop/�����Ӿ�/week11.jpg");
	if (!src.data)
	{
		return -1;
	}
	float r1 = 0.3f;
	float r2 = 3.0f;
	Mat src1 = gammaTrans(src, r1);
	Mat src2 = gammaTrans(src, r2);
	imshow("src1", src1);
	imshow("src2", src2);

	waitKey(0);
	return 0;


}

