
#include<stdio.h>
#include<opencv.hpp>

using namespace std;
using namespace cv;

//��ϰ1
int main()
{
	cv::Mat dstMat;
	cv::Mat srcMat = cv::imread("C:\\Users\\hurricane\\Desktop\\�����Ӿ�\\2.jpg", 1);

	if (srcMat.empty())
	{
		return -1;
	}
	float angle = 10.0, scale = 1;//Ĭ��Ϊ��ʱ����ת�����ű�ʾ˳ʱ����ת
	cv::Point2f center(srcMat.cols * 0.5, srcMat.rows * 0.5);
	cv::Mat rot = cv::getRotationMatrix2D(center, angle, scale);

	//ȷ���߽����
	cv::Rect bbox = cv::RotatedRect(center, srcMat.size(), angle).boundingRect();

	//�����任����
	rot.at<double>(0, 2) += bbox.width / 2.0 - center.x;
	rot.at<double>(1, 2) += bbox.height / 2.0 - center.y;

	//����任����
	cv::warpAffine(srcMat, dstMat, rot, bbox.size());

	cv::imshow("src", srcMat);
	cv::imshow("dst", dstMat);

	cv::waitKey(0);

	return 0;
}

//��ϰ2
//int main()
//{
//	//cv::Mat src = imread("C:\\Users\\hurricane\\Desktop\\�����Ӿ�\\road.jfif");
//	cv::Mat src = imread("C:\\Users\\hurricane\\Desktop\\�����Ӿ�\\4.jpg");
//	cv::Mat bsrc;
//	cv::Mat src_gray;
//	cv::Mat src_canny;
//	cvtColor(src, src_gray, COLOR_BGR2GRAY);
//
//	threshold(src_gray, bsrc, 125, 255, CV_THRESH_BINARY);
//	cv::Canny(bsrc, src_canny, 50, 150, 3);
//
//	std::vector<cv::Vec2f> lines;
//	cv::HoughLines(src_canny, lines, 1, CV_PI / 180, 100); 
//
//	cv::Mat lineMat;
//	cv::HoughLines(src_canny, lineMat, 1, CV_PI / 180, 100);
//	float r = lines[0][0];
//	float t = lines[0][1];
//
//	//drowlines
//	std::vector<cv::Vec2f>::iterator it = lines.begin();
//	for (; it != lines.end(); ++it) {
//		float rho = (*it)[0], theta = (*it)[1];
//		cv::Point pt1, pt2;
//		double a = cos(theta);
//		double b = sin(theta);
//		double x0 = a*rho;
//		double y0 = b*rho;
//		pt1.x = cv::saturate_cast<int>(x0 + 1000 * (-b));
//		pt1.y = cv::saturate_cast<int>(y0 + 1000 * (a));
//		pt2.x = cv::saturate_cast<int>(x0 - 1000 * (-b));
//		pt2.y = cv::saturate_cast<int>(y0 - 1000 * (a));
//		cv::line(src, pt1, pt2, cv::Scalar(255, 0, 255), 1, CV_AA);
//	}
//	imshow("src", src);
//
//	waitKey(0);
//
//	return 0;
//}

//��ϰ3
//int main()
//{
//	//cv::Mat src = imread("C:\\Users\\hurricane\\Desktop\\�����Ӿ�\\road.jfif");
//	cv::Mat src = imread("C:\\Users\\hurricane\\Desktop\\�����Ӿ�\\4.jpg");
//	cv::Mat bsrc;
//	cv::Mat src_gray;
//	cv::Mat src_canny;
//	cvtColor(src, src_gray, COLOR_BGR2GRAY);
//
//	threshold(src_gray, bsrc, 125, 255, CV_THRESH_BINARY);
//	cv::Canny(bsrc, src_canny, 50, 150, 3);
//
//	std::vector<cv::Vec4i> lines;
//	cv::HoughLinesP(src_canny, lines, 1, CV_PI / 180, 35, 10, 10); 
//
//	cv::Mat lineMat;
//	cv::HoughLinesP(src_canny, lineMat, 1, CV_PI / 180, 35, 10, 10);
//
//	for (size_t i = 0; i < lines.size(); i++)
//	{
//		cv::Vec4i lineNum = lines[i];
//		line(src, cv::Point(lineNum[0], lineNum[1]), cv::Point(lineNum[2], lineNum[3]), cv::Scalar(0, 0, 255), 1, CV_AA);
//	}
//
//	imshow("result", src);
//	cout <<  endl << lineMat << endl << endl;
//
//	waitKey(0);
//
//	return 0;
//}